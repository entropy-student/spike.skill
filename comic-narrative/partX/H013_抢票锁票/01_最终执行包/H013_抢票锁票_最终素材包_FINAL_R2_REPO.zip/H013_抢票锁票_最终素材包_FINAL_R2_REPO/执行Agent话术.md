# H013｜生图执行 Agent 话术｜FINAL_R2

你将执行 H013「抢票锁票」的图片任务。

## 唯一事实源
- 逐图执行：`图片任务.json`
- 参考图 hash：`REFERENCE_MANIFEST.json`
- 资产与连续性：`ASSET_MANIFEST.json`
- 上游导演结构：`上游锁定输入/H013_抢票锁票_Part3_Shotbook_R3_MINIMAL_REPAIR.json`

## 执行边界
1. 不访问仓库补充创意决定，不重新查素材库。
2. 最大并发 = 2。
3. 严格遵守 `prerequisites`；run reference 只有 QA=ACCEPTED 且 hash 已记录才可使用。
4. `EXACT_REUSE` 不调用 imagegen、不裁切、不改图；本版仅保留 5 个真正必要的回看/重解释复用。
5. `DERIVE_EDIT` 只使用任务指定的唯一 full-frame source。
6. 输出 `outputs/<task_id>/<task_id>.png`；16:9；1920×1080 final target；native pixel target = NONE。
7. 禁止 COMPOSITE_CROP / 外部图层拼装 / POST_OVERLAY。
8. exact_required_text 必须 native 准确；失败返回 `UI_TEXT_FAILURE`。
9. 不把 Ticketmaster 官方文档画成消费者票务 App；不把 generic UI 加真实品牌。
10. 本包时间为 provisional planning exception，不得据此改口播/TTS速度或宣称正式音频对齐。
11. B34 的 `characters_visible` 已按 Owner 同意做最小一致性修复：双人中景保留主角 + 男生朋友。
12. 当前包无 HOLD 任务；如执行中发现新的上游语义冲突，返回 `RETURN_TO_PART3`，不要自行补设定。
