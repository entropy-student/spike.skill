# H013 抢票锁票｜最终素材包 FINAL_R2

这是在 `READY_R1` 基础上完成两项定向修订后的最终执行素材包：

1. **HOLD 收口**：B34 的上游字段冲突已按 Owner 同意做最小一致性修复，因此包内不再保留 HOLD 任务。
2. **EXACT_REUSE 收缩**：中段过高的内部复用已收缩，只保留 5 个真正需要“就是同一状态”的复用 Beat。

## 当前状态

`READY_FOR_IMAGE_EXECUTOR_UNDER_OWNER_PROVISIONAL_TIMING_EXCEPTION_FINALIZED`

## 任务结构

- Beat：40
- GENERATE：28
- DERIVE_EDIT：7
- EXACT_REUSE：5
- HOLD：0
- imagegen 实际任务：35

## 仍保留的生产边界

- 当前时间字段仍来自 provisional SRT，只用于规划，不宣称正式音频对齐。
- 最终配音出来后，仍需做 Timing Rebind；但这不阻止当前图片任务执行。
