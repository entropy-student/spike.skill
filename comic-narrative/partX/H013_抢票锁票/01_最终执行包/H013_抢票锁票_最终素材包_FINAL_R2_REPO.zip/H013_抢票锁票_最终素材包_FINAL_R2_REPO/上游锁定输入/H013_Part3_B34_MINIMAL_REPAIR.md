# H013｜Part 3 最小上游修复说明

Part 4 跨模块检查发现 B34 字段自相矛盾：

- `shot_scale = 双人中景`；
- `final_static_state` 明确“朋友在旁边”；
- 但 `characters_visible` 仅登记 `CHAR_MAIN`。

本轮只做一个最小事实一致性修复：

`B34.characters_visible = [CHAR_MAIN, CHAR_MALE_FRIEND]`

并在 continuity 中补入男生朋友身份锁。

没有修改：剧情、口播、Scene、POV、景别、最终静帧意义、setup/reveal 或 Beat 数量。

该修复作为本图片执行包的上游输入快照；未擅自回填 GitHub canonical Part 3 文档。
