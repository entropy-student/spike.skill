# H013 — Part 3 整集视觉策略（源文档复查修正版）

## 0. 正式状态

**`RETURN_TIMING_INPUT_NOT_READY / STRUCTURAL_DIRECTOR_DRAFT_REVIEWED`**

依据 GitHub `main` 的当前 `part3/STORYBOARD_VISUAL_DIRECTOR.md`，上一版把 provisional SRT 时间写入 Part 3 正式时间字段是不合规的。

当前正式 Part 3 仍缺：
1. 最终配音音频；
2. 与真实音频对齐的正式 SRT；
3. 必要停顿 / 静默信息。

因此本包只保留已经可以独立成立的视觉导演结构；正式 timing 全部保持 `PENDING`。

## 1. 长期视觉基线

### Character Master
- `assets/characters/MAIN_CHARACTER_MASTER.png`
- `assets/characters/MALE_FRIEND_ROOMMATE_MASTER.png`
- `assets/characters/FEMALE_FRIEND_COLLEAGUE_MASTER.png`

本集只使用主角与男生朋友；女生长期角色不出场。

### Style Plate
- `assets/style/STYLE_PRIMARY_TWO_PERSON_DINING.png`
- `assets/style/STYLE_SECONDARY_SINGLE_PERSON_DINING.png`

只继承线条、上色、人物比例、阴影材质、色彩关系与整体气质，不继承具体餐桌、食物、姿势和构图。

视觉边界：**温暖、简化、生活化的手绘叙事漫画感**；禁止 Q 版 / 幼态、霓虹科技感、PPT / 信息图。

## 2. 主视觉发动方式

**行动 / 反应 + 调查 / 发现 + 真实 UI / 官方文档证据。**

票务 UI 可以高频出现，但必须是故事动作、状态或来源证据。禁止三阶段流程图、漂浮规则卡、解释箭头和抽象锁头。

次视觉发动：
- 第二次抢票中的关系对话；
- 结尾对已经建立过的可售 / hold / confirmation 状态做短回看。

## 3. Scene System

本集只有 **1 个物理地点**，但有 **4 个剧情 Scene / 状态阶段**：

| Scene | 物理空间 | 进入 | 离开 | 故事任务 |
|---|---|---|---|---|
| SC01_DAY1_TICKETING | 主角家中固定桌位 | 开票模拟开始 | 主角停止重试、决定查证 | 两次可选→不可用制造真实困惑 |
| SC02_DAY1_RESEARCH | 同一桌位 / 研究状态 | 打开公开文档 | 理解 hold 后还有 final commit | 拆开可售、预留、最终确认 |
| SC03_DAY2_RETRY | 同一桌位 / 第二天 | 收到加场消息后再次抢票 | 订单确认 + 关系 payoff | 让理解真正改变人物行为 |
| SC04_POST_CONFIRM_RECAP | SC03 同一空间 | 庆祝后 | 回到当前人物结束 | 用既有状态短回看完成收束 |

Scene 按剧情状态判断，不按地点数。

## 4. Scene Anchor

### SC01
稳定：主角身份、桌位、手机、两张连座数量、generic ticket UI shell。  
允许变化：座位可选 / 不可用；主角期待 → 恼火 → 怀疑。  
禁止：提前出现倒计时、最终订单、Ticketmaster 品牌消费者 UI。

### SC02
稳定：同一主角 / 桌位 / 手机 / 研究笔记本；官方文档与消费者 UI 必须视觉区分。  
允许变化：文档页、generic UI 状态、主角认知。

### SC03
稳定：主角 + 男生朋友身份、同一桌位 / 手机 / generic UI shell、两张连座数量。  
允许变化：可选 → hold → loading → confirmation；两人关系状态由紧张 → 判断分歧 → 最终庆祝。

### SC04
稳定：当前人物、第二天桌位、回看 UI 与前文状态一致。  
允许：已建立状态之间的 montage；人物由兴奋回到平静理解。

## 5. 视觉母题

1. **两张相邻座位**：贯穿“看得见 → hold → 最终确认”。
2. **延迟庆祝**：朋友在第二次抢票看到倒计时先庆祝，主角主动按住，直到 confirmation 才兑现。

## 6. 文本 / UI

需要可读：
- `座位不可用`
- `Availability / Reserve Tickets / Commit Cart / hold_time / Delete Cart`
- `Selected tickets are no longer available`
- `Why is there a time limit for checking out?`
- `加场了，明天十点。`

不要求可读：
- 倒计时具体数字；
- 票价、订单号、座位区号；
- confirmation 的具体文案；
- 消费者 UI 品牌名。

仅允许 `TEXT_RENDER_MODE = NONE / IMAGE_NATIVE`，不允许后期文字覆盖修错。

## 7. 事实属性

必须持续区分：
- 客观故事事件；
- Ticketmaster 官方来源证据；
- generic hold / release 的一般机制示范；
- 结尾已建立状态回看。

一般机制示范不能被剪成“主角第一次失败就是这个后台原因”。

## 8. 画面关系

- 第一次抢票：setup → reveal → setup → reveal/reaction
- 查证：character action → evidence setup → evidence reveal
- 理解：established-state recap → evidence → general mechanism demo → character realization
- 第二次抢票：setup → hold reveal → relation reaction → decision → action → confirmation payoff
- 结尾：current reflection → established-state montage → relational close

## 9. 防重复

不新增地点或陌生角色来制造多样性。

主动避免：
- 长时间同构“坐桌前看手机”；
- 连续同类 UI；
- 每个机制点另开一页解释屏；
- 无理由随机换机位。

研究段允许连续 evidence insert，但每张必须新增不同证据。

## 10. 当前时间 Gate

源文档规定：

> Part 3 正式时间 = 最终真实音频 + 正式对齐 SRT。

因此本包：
- 不填写正式 start / end / duration；
- 不使用上一版 3:20.478 作为正式 Part 3 时间；
- 不用平均秒数决定 Beat 是否拆分；
- Cue Range 只用于文本覆盖追溯；
- cut / hold / handoff 标为 `TO_BE_LOCKED_AFTER_REAL_AUDIO`。

## 11. 与 Part 4 边界

Part 3 锁：Beat 意义、事实属性、state_before / state_after、最终静帧、景别、POV、构图、Scene/continuity、setup/reveal、必要文字、acceptance criteria。

Part 4 决定：素材检索、reference、GENERATE / DERIVE_EDIT / EXACT_REUSE、source frame、prompt、output / hash。

在真实音频到位前，本包不得被描述成正式 Part 3 PASS。
