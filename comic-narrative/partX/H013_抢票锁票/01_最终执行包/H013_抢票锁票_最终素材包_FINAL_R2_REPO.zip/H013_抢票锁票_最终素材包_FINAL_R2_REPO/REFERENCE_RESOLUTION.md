# GitHub repo-native reference resolution

本目录是 H013 最终素材包的 GitHub 仓库归档版。

为避免在同一仓库重复存储已经存在的 canonical PNG binary，执行包中的 4 张参考图不在 Part X 再复制；执行时直接解析到当前仓库 canonical 路径：

- `参考图片/MAIN_CHARACTER_MASTER.png` → `comic-narrative/part3/assets/characters/MAIN_CHARACTER_MASTER.png`
- `参考图片/MALE_FRIEND_ROOMMATE_MASTER.png` → `comic-narrative/part3/assets/characters/MALE_FRIEND_ROOMMATE_MASTER.png`
- `参考图片/STYLE_PRIMARY_TWO_PERSON_DINING.png` → `comic-narrative/part3/assets/style/STYLE_PRIMARY_TWO_PERSON_DINING.png`
- `参考图片/STYLE_SECONDARY_SINGLE_PERSON_DINING.png` → `comic-narrative/part3/assets/style/STYLE_SECONDARY_SINGLE_PERSON_DINING.png`

四张图的 Git blob SHA / SHA-256 仍以 `REFERENCE_MANIFEST.json` 为准。

原始完整 transport ZIP（含 4 张 PNG binary）：`H013_抢票锁票_最终素材包_FINAL_R2.zip`。
